const K='qc-tracker-v1',STAGES=['Incoming','Machining','Assembly','Final','Packaging'],SEV=['Minor','Major','Critical'],STATUS=['Pending','In inspection','Passed','Failed','On hold'];
const $=s=>document.querySelector(s),uid=p=>p+Math.random().toString(36).slice(2,7).toUpperCase(),today=()=>new Date().toISOString().slice(0,10);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const by=(a,id)=>a.find(x=>x.id===id)||{};
const opts=(a,f,sel)=>a.map(x=>{const v=x.id??x;return `<option value="${esc(v)}" ${v===sel?'selected':''}>${esc(f(x))}</option>`}).join('');
const badge=s=>`<span class="b ${String(s).toLowerCase().replace(/ /g,'-')}">${esc(s)}</span>`;
const sumQty=a=>a.reduce((s,d)=>s+d.qty,0);
let S={},db=load();
function load(){try{const d=JSON.parse(localStorage.getItem(K));if(d&&d.batches)return d}catch(e){}
 const c=[['Material certificate','Incoming','Matches PO specification'],['Dimensions','Machining','Within ±0.05 mm'],['Joint fit','Assembly','No gaps over 0.2 mm'],['Surface finish','Final','No scratches over 1 mm'],['Functional test','Final','Runs 30 s without fault'],['Label and seal','Packaging','Correct label, seal intact']].map(([name,stage,spec])=>({id:uid('C'),name,stage,spec}));
 return{batches:[],criteria:c,inspectors:[{id:uid('I'),name:'A. Sharma',emp:'EMP-101',shift:'Day'},{id:uid('I'),name:'R. Costa',emp:'EMP-102',shift:'Night'}],inspections:[],defects:[]}}
const save=()=>{try{localStorage.setItem(K,JSON.stringify(db))}catch(e){}};
function toast(m){const t=document.createElement('div');t.className='toast';t.textContent=m;document.body.append(t);setTimeout(()=>t.remove(),2600)}
function recalc(id){const b=by(db.batches,id),last={};
 db.inspections.filter(i=>i.batchId===id).forEach(i=>{if(!last[i.stage]||i.date>=last[i.stage].date)last[i.stage]=i});
 const A=Object.values(last);
 b.status=!A.length?'Pending':A.some(i=>i.results.some(r=>!r.pass))?'Failed':A.some(i=>i.stage==='Final'||i.stage==='Packaging')?'Passed':'In inspection'}
function record(bid,n,st,date,notes,res){const id=uid('N');
 db.inspections.push({id,batchId:bid,inspector:n.name+' ('+n.emp+')',stage:st,date,notes,results:res.map(r=>({cid:r.cid,name:r.name,pass:r.pass}))});
 res.filter(r=>!r.pass).forEach(r=>db.defects.push({id:uid('D'),inspectionId:id,batchId:bid,stage:st,crit:r.name,desc:r.desc||'',sev:r.sev,qty:r.qty,date,inspector:n.name}));
 recalc(bid)}
const V={batches,inspect,defects,setup,reports};
function go(v){S.v=v;document.querySelectorAll('#nav button').forEach(b=>b.classList.toggle('on',b.dataset.v===v));$('#app').innerHTML=V[v]()}
$('#nav').onclick=e=>{if(e.target.dataset.v)go(e.target.dataset.v)};

/* Batches */
function batches(){const f=S.f||'All',L=db.batches.filter(b=>f==='All'||b.status===f);
 return `<section class="card"><h2>Register a product batch</h2><div class="grid">
 <label>Batch number<input id="bn" placeholder="B-2026-001"></label>
 <label>Product<input id="bp" placeholder="Brake caliper"></label>
 <label>Quantity<input id="bq" type="number" min="1" value="100"></label>
 <label>Production date<input id="bd" type="date" value="${today()}"></label>
 <label>Production line<input id="bl" placeholder="Line 1"></label></div>
 <button class="pri" onclick="addBatch()">Add batch</button></section>
 <section class="card"><div class="bh"><h2>Batches (${L.length})</h2><select onchange="S.f=this.value;go('batches')" aria-label="Filter by status">${opts(['All',...STATUS],x=>x,f)}</select></div>
 ${L.length?`<div class="tw"><table><tr><th>Batch</th><th>Product</th><th>Qty</th><th>Date</th><th>Line</th><th>Inspections</th><th>Defective units</th><th>Status</th><th></th></tr>
 ${L.map(b=>`<tr><td><b>${esc(b.no)}</b></td><td>${esc(b.product)}</td><td>${b.qty}</td><td>${b.date}</td><td>${esc(b.line)}</td><td>${db.inspections.filter(i=>i.batchId===b.id).length}</td><td>${sumQty(db.defects.filter(d=>d.batchId===b.id))}</td>
 <td>${badge(b.status)} <select aria-label="Set status" onchange="setStatus('${b.id}',this.value)">${opts(STATUS,x=>x,b.status)}</select></td><td><button class="ghost" onclick="delBatch('${b.id}')">Delete</button></td></tr>`).join('')}</table></div>`:'<p class="mut">No batches yet. Register one above, or load demo data in Setup.</p>'}</section>`}
function addBatch(){const no=$('#bn').value.trim(),product=$('#bp').value.trim();
 if(!no||!product)return toast('Enter a batch number and product.');
 if(db.batches.some(b=>b.no===no))return toast('That batch number already exists.');
 db.batches.push({id:uid('B'),no,product,qty:+$('#bq').value||1,date:$('#bd').value||today(),line:$('#bl').value.trim(),status:'Pending'});save();go('batches');toast('Batch added.')}
function setStatus(id,v){by(db.batches,id).status=v;save();go('batches')}
function delBatch(id){if(!confirm('Delete this batch with its inspections and defects?'))return;
 db.batches=db.batches.filter(b=>b.id!==id);db.inspections=db.inspections.filter(i=>i.batchId!==id);db.defects=db.defects.filter(d=>d.batchId!==id);save();go('batches')}

/* Inspect */
function inspect(){
 if(!db.batches.length||!db.inspectors.length)return '<section class="card"><p>Register at least one batch (Batches tab) and one inspector (Setup tab) before recording an inspection.</p></section>';
 const st=S.stage||'Final',cr=db.criteria.filter(c=>c.stage===st);
 return `<section class="card"><h2>Record an inspection</h2><div class="grid">
 <label>Batch<select id="ib">${opts(db.batches,b=>b.no+' – '+b.product,S.batch)}</select></label>
 <label>Inspector<select id="ii">${opts(db.inspectors,i=>i.name+' ('+i.emp+')',S.insp)}</select></label>
 <label>Stage<select id="is" onchange="S.batch=$('#ib').value;S.insp=$('#ii').value;S.stage=this.value;go('inspect')">${opts(STAGES,x=>x,st)}</select></label>
 <label>Date<input id="id" type="date" value="${today()}"></label></div>
 ${cr.length?cr.map(c=>`<div class="crit"><div class="r"><div><b>${esc(c.name)}</b><small>${esc(c.spec)}</small></div>
 <label class="rd"><input type="radio" name="r_${c.id}" value="p">Pass</label><label class="rd"><input type="radio" name="r_${c.id}" value="f">Fail</label></div>
 <div class="d grid"><label>Defective units<input id="q_${c.id}" type="number" min="1" value="1"></label><label>Severity<select id="s_${c.id}">${opts(SEV,x=>x,'Major')}</select></label><label>What went wrong<input id="t_${c.id}" placeholder="e.g. scratch on rim"></label></div></div>`).join(''):'<p class="mut">No criteria for this stage. Add some in Setup.</p>'}
 <label>Notes<textarea id="in" rows="2"></textarea></label>
 <button class="pri" onclick="saveInsp()">Save inspection</button></section>
 <section class="card"><h2>Recent inspections</h2>${db.inspections.length?`<div class="tw"><table><tr><th>Date</th><th>Batch</th><th>Stage</th><th>Inspector</th><th>Result</th></tr>
 ${db.inspections.slice(-8).reverse().map(i=>{const f=i.results.filter(r=>!r.pass).length;return `<tr><td>${i.date}</td><td>${esc(by(db.batches,i.batchId).no)}</td><td>${i.stage}</td><td>${esc(i.inspector)}</td><td>${badge(f?'Failed':'Passed')} <small style="display:inline">${f?f+' of '+i.results.length+' checks failed':'all checks passed'}</small></td></tr>`}).join('')}</table></div>`:'<p class="mut">Nothing recorded yet.</p>'}</section>`}
function saveInsp(){const b=by(db.batches,$('#ib').value),n=by(db.inspectors,$('#ii').value),st=$('#is').value,cr=db.criteria.filter(c=>c.stage===st),res=[];
 if(!cr.length)return toast('This stage has no criteria. Add some in Setup.');
 for(const c of cr){const r=document.querySelector(`input[name="r_${c.id}"]:checked`);if(!r)return toast('Mark Pass or Fail for: '+c.name);
  res.push({cid:c.id,name:c.name,pass:r.value==='p',qty:+$('#q_'+c.id).value||1,sev:$('#s_'+c.id).value,desc:$('#t_'+c.id).value.trim()})}
 record(b.id,n,st,$('#id').value||today(),$('#in').value.trim(),res);S.batch=b.id;S.insp=n.id;save();go('inspect');toast('Saved. Batch '+b.no+' is now '+b.status+'.')}

/* Defects */
function defects(){const fb=S.db||'',fs=S.ds||'',L=db.defects.filter(d=>(!fb||d.batchId===fb)&&(!fs||d.stage===fs)).slice().reverse();
 return `<section class="card"><div class="bh"><h2>Defect records (${L.length})</h2><div class="bh">
 <select onchange="S.db=this.value;go('defects')" aria-label="Filter by batch"><option value="">All batches</option>${opts(db.batches,b=>b.no,fb)}</select>
 <select onchange="S.ds=this.value;go('defects')" aria-label="Filter by stage"><option value="">All stages</option>${opts(STAGES,x=>x,fs)}</select></div></div>
 ${L.length?`<div class="tw"><table><tr><th>Date</th><th>Batch</th><th>Stage</th><th>Failed check</th><th>Description</th><th>Severity</th><th>Units</th><th>Inspector</th></tr>
 ${L.map(d=>`<tr><td>${d.date}</td><td>${esc(by(db.batches,d.batchId).no)}</td><td>${d.stage}</td><td>${esc(d.crit)}</td><td>${esc(d.desc)}</td><td>${badge(d.sev)}</td><td>${d.qty}</td><td>${esc(d.inspector)}</td></tr>`).join('')}</table></div>`:'<p class="mut">No defects recorded. Defects are created when you mark a check as Fail on the Inspect tab.</p>'}</section>`}

/* Setup */
function setup(){return `<div class="two"><section class="card"><h2>Inspection criteria</h2><div class="grid">
 <label>Check<input id="cn" placeholder="Surface finish"></label><label>Stage<select id="cs">${opts(STAGES,x=>x,'Final')}</select></label><label>Accept when<input id="cp" placeholder="No scratches over 1 mm"></label></div>
 <button class="pri" onclick="addCrit()">Add criterion</button><div class="tw"><table>${STAGES.flatMap(s=>db.criteria.filter(c=>c.stage===s)).map(c=>`<tr><td><b>${esc(c.name)}</b><small>${esc(c.spec)}</small></td><td>${c.stage}</td><td><button class="ghost" onclick="del('criteria','${c.id}')">Delete</button></td></tr>`).join('')}</table></div></section>
 <section class="card"><h2>Inspectors</h2><div class="grid"><label>Name<input id="in1" placeholder="Full name"></label><label>Employee ID<input id="in2" placeholder="EMP-103"></label><label>Shift<select id="in3"><option>Day</option><option>Evening</option><option>Night</option></select></label></div>
 <button class="pri" onclick="addInspector()">Add inspector</button><div class="tw"><table>${db.inspectors.map(i=>`<tr><td><b>${esc(i.name)}</b><small>${esc(i.emp)}</small></td><td>${i.shift} shift</td><td><button class="ghost" onclick="del('inspectors','${i.id}')">Delete</button></td></tr>`).join('')}</table></div></section></div>
 <section class="card"><h2>Data</h2><p class="mut">Records are stored in this browser only. Export a CSV from Reports to keep a copy.</p><button class="pri" onclick="demo()">Load demo data</button> <button class="ghost" onclick="resetAll()">Erase all data</button></section>`}
function addCrit(){const name=$('#cn').value.trim();if(!name)return toast('Enter a check name.');db.criteria.push({id:uid('C'),name,stage:$('#cs').value,spec:$('#cp').value.trim()});save();go('setup')}
function addInspector(){const name=$('#in1').value.trim();if(!name)return toast('Enter the inspector name.');db.inspectors.push({id:uid('I'),name,emp:$('#in2').value.trim()||'-',shift:$('#in3').value});save();go('setup')}
function del(k,id){db[k]=db[k].filter(x=>x.id!==id);save();go('setup')}
function resetAll(){if(confirm('Erase every batch, inspection and defect?')){localStorage.removeItem(K);db=load();go('setup')}}
function demo(){const n=db.inspectors[0];if(!n)return toast('Add an inspector first.');
 [['B-1001','Brake caliper',200,[0,0]],['B-1002','Brake caliper',180,[4,3]],['B-1003','Gear housing',120,[0,2]]].forEach(([no,product,qty,bad],k)=>{
  if(db.batches.some(b=>b.no===no))return;const b={id:uid('B'),no,product,qty,date:today(),line:'Line '+(k%2+1),status:'Pending'};db.batches.push(b);
  ['Machining','Final'].forEach((st,j)=>record(b.id,n,st,today(),'',db.criteria.filter(c=>c.stage===st).map((c,x)=>({cid:c.id,name:c.name,pass:!bad[j]||x>0,qty:bad[j],sev:'Major',desc:'Demo defect'}))))});
 save();go('batches');toast('Demo data loaded.')}

/* Reports */
function reports(){const I=db.inspections,D=db.defects,B=db.batches,n=s=>B.filter(b=>b.status===s).length;
 const fp=I.length?Math.round(I.filter(i=>i.results.every(r=>r.pass)).length/I.length*100)+'%':'–';
 const tally=(k,o)=>{D.forEach(d=>o[d[k]]=(o[d[k]]||0)+d.qty);return o},st={};STAGES.forEach(s=>st[s]=0);
 const bars=o=>{const m=Math.max(1,...Object.values(o));return Object.entries(o).map(([k,v])=>`<div class="bar"><span>${esc(k)}</span><i style="width:${v/m*100}%"></i><b>${v}</b></div>`).join('')};
 const pb=B.map(b=>({b,n:sumQty(D.filter(d=>d.batchId===b.id))})).filter(x=>x.n||x.b.status==='Failed').sort((a,c)=>c.n-a.n);
 const ip={};I.forEach(i=>{const o=ip[i.inspector]=ip[i.inspector]||{n:0,f:0};o.n++;if(i.results.some(r=>!r.pass))o.f++});
 return `<div class="kpis"><div class="kpi"><b>${B.length}</b>Batches</div><div class="kpi"><b>${n('Passed')}</b>Passed</div><div class="kpi"><b>${n('Failed')}</b>Failed</div><div class="kpi"><b>${fp}</b>First-pass yield</div><div class="kpi"><b>${sumQty(D)}</b>Defective units</div></div>
 <div class="two"><section class="card"><h2>Defects by production stage</h2>${bars(st)}</section><section class="card"><h2>Defects by failed check</h2>${D.length?bars(tally('crit',{})):'<p class="mut">No defects yet.</p>'}</section></div>
 <section class="card"><div class="bh"><h2>Problem batches</h2><span class="noprint"><button class="pri" onclick="exportCsv()">Export CSV</button> <button class="ghost" onclick="print()">Print report</button></span></div>
 ${pb.length?`<div class="tw"><table><tr><th>Batch</th><th>Product</th><th>Defective units</th><th>Defect rate</th><th>Status</th></tr>${pb.map(({b,n})=>{const r=n/b.qty*100;return `<tr class="${r>=5?'warn':''}"><td><b>${esc(b.no)}</b></td><td>${esc(b.product)}</td><td>${n}</td><td>${r.toFixed(1)}%</td><td>${badge(b.status)}</td></tr>`}).join('')}</table></div><small>Rows shaded red have a defect rate of 5% or more.</small>`:'<p class="mut">No problem batches found.</p>'}</section>
 <section class="card"><h2>Inspector activity</h2>${I.length?`<div class="tw"><table><tr><th>Inspector</th><th>Inspections</th><th>With failures</th></tr>${Object.entries(ip).map(([k,o])=>`<tr><td>${esc(k)}</td><td>${o.n}</td><td>${o.f}</td></tr>`).join('')}</table></div>`:'<p class="mut">No inspections yet.</p>'}</section>`}
function exportCsv(){const R=[['Date','Batch','Product','Stage','Inspector','Check','Result','Defective units','Severity','Description','Notes']];
 db.inspections.forEach(i=>{const b=by(db.batches,i.batchId);i.results.forEach(r=>{const d=db.defects.find(d=>d.inspectionId===i.id&&d.crit===r.name)||{};R.push([i.date,b.no,b.product,i.stage,i.inspector,r.name,r.pass?'Pass':'Fail',d.qty||'',d.sev||'',d.desc||'',i.notes||''])})});
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([R.map(r=>r.map(v=>'"'+String(v??'').replace(/"/g,'""')+'"').join(',')).join('\n')],{type:'text/csv'}));a.download='qc-report.csv';a.click()}
go('batches');
